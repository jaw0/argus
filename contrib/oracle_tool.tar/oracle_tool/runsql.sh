#!/usr/bin/ksh -p
SQLPATH=/opt/racqbin/oracle_monitor
ORACLE_HOME=/opt/oracle/product/9.0.2
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH

USER="someuser"
PASSWD="noonehome"

if [ $# -ne 2 ]
then
	echo "$0 SID SQL_SCRIPT PASSWORD"
	exit
fi
SID=$1
PRG=$2

if [ ! -f ${PROG} ]
then
	echo "${PROG} can not be found\c"
	exit
fi

VALUE=`sqlplus -s ${USER}/${PASSWD}@${SID} @${SQLPATH}/${PRG} | sed 's/^ //g'`
echo "${VALUE}\c"
