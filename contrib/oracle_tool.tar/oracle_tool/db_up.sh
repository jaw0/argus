#!/bin/ksh -p
SQLPATH=/opt/racqbin/oracle_monitor
ORACLE_HOME=/opt/oracle/product/9.0.2
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH

USER="someuser"
PASS="somepw"

if [ $# -ne 1 ]
then
	echo "$0 SID"
	echo "No SID supplied"
else
	SID=$1
fi


RESULT=`print "select dummy||'OK' from dual;" | sqlplus -s $USER/$PASS@$SID | grep XOK 2>&1`

if [ "${RESULT}" = "XOK" ]
then
	echo "1\c"
else
	echo "0\c"
fi
