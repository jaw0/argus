set echo off
set pages 0
set feedback off

select ltrim(round(v$sgastat.bytes / to_number(v$parameter.value) * 100,2))
from v$sgastat, v$parameter
where  
   v$sgastat.name = 'free memory' and 
   v$sgastat.pool = 'shared pool' and
   v$parameter.name = 'shared_pool_size'
/

exit;
