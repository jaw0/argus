set echo off
set pages 0
set feedback off

select ltrim(count(distinct username))
from v$session
where username is not null
/

exit;
