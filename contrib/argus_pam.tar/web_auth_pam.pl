# -*- perl -*-
# replacement web_auth
#
# use system passwd/groups
# just like old argus

# Pam-authentication
# QUICK-INSTALL:
# 1. Compile helper-programm check_user.c using
# 	 gcc -o check_user check_user.c -lpam -lpam_misc
# 2. Copy check_user to /usr/local/lib/argus
# 3. chown root.root /usr/local/lib/argus/check_user
# 4. Setuid: chmod u+s /usr/local/lib/argus/check_user
# 5. create file /etc/pam.d/argus with the lines
# 	auth       required     pam_unix_auth.so
# 	account    required     pam_unix_acct.so
# or whatever you need!
# 6. copy web_auth_pam.pl to /usr/local/lib/argus/web_auth_file.pl 
# 
# user's home object is always 'Top'
# returns list of unix groups as access control groups
#
# 2003-06-13 Hans M Kr�ger (hans@wh2.tu-dresden.de)

use IPC::Open2;
use IO;

sub auth_user {
  my $user = shift;
  my $pass = shift;

	my $COMMAND = "/usr/local/lib/argus/check_user $user 2>/dev/null";

	open2(RC, WC, $COMMAND) || die "$!\n";
  print WC "$pass\n";
	close WC;

	my $line;
	while ($line = <RC>) { 
		# get last line!
		chomp($line);
		last if ( $line eq "Authenticated");
	};
	close RC;
		
  if( $line eq "Authenticated"){
		my $g = `groups $user`;
		chop $g;
		my @g = split /\s+/, $g;

		return ('Top', @g);
  }
  return ;
}

auth_user("argus","test");

1;
